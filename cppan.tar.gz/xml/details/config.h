/* file      : xml/details/config.h.in
 * copyright : Copyright (c) 2013-2014 Code Synthesis Tools CC
 * license   : MIT; see accompanying LICENSE file
 */

/* This file is automatically processed by configure. */

#ifndef XML_DETAILS_CONFIG_H
#define XML_DETAILS_CONFIG_H

#define LIBSTUDXML_STATIC_LIB 1

#endif /* XML_DETAILS_CONFIG_H */
